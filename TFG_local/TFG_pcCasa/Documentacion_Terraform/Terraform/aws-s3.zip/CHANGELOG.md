# Change Log

All notable changes to this project will be documented in this file.

<a name="v1.1"></a>
## [v1.1] - 2021-10-27

- Naming convention changes
- Add policies
- Add static webhost
...


<a name="v1.0"></a>
## [v1.0.0] - 2021-01-01

- First version


[v1.1]: https://github.com/terraform-aws-modules/terraform-aws-s3-bucket/compare/v1.0...v1.1.
