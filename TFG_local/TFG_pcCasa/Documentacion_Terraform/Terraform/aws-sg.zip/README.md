# Módulo SG

El módulo genera un security group y las reglas de acceso y salida que se definan en los mapas de variables.

## Parametros de entrada:

*  **sg_name** (string): nombre del security group (el módulo le añade el prefijo `sg-`).
*  **sg_description** (string): descripción del security group
*  **vpc_id** (string): id de la VPC donde desplegar el SG

*  **rule_sg** (map(map)): mapa donde se define la configuración de las reglas de firewall asociadas a otros security groups
```
  rule_sg = {
    rule1 = {
      from_port   = "3000"
      to_port     = "3005"
      type        = "ingress" #ingress o egress
      protocol    = "tcp"
      from_group  = module.sg-test2.sg-id
      description = "ingrees for sg-test2 security group"
    }
  }
```
*  **rule_cidr** (map(map)): mapa donde se define la configuración de las reglas de firewall asociadas a IPs o subredes

```
  rule_cidr = {
    rule1 = {
      from_port   = "3000"
      to_port     = "3005"
      type        = "ingress" #ingress o egress
      protocol    = "tcp"
      from_cidr = ["10.0.0.128/25"]
      description = "ingress for DMZ network"
    }
    rule2 = {
      from_port   = "3000"
      to_port     = "3005"
      type        = "ingress" #ingress o egress
      protocol    = "tcp"
      from_cidr = [module.instance-test.ec2-ip]
      description = "ingress for instance-test IP"
    }
  }
```

## Recursos generados:
*  **security group**: genera un security group
*  **reglas de ingreso**: genera N reglas de ingreso asociadas el SG creado
*  **reglas de salida**: genera N reglas de salida asociadas el SG creado

## Salidas del módulo:
*  **sg-id**: id del security group generado.
*  **sg-arn**: arn del security group generado.
*  **rule-sg**: id de las reglas generadas entre SGs.
*  **rule-cidr** id de las reglas generadas entre cidrs y SGs.


## Ejemplos:

**Ejemplo**: Un security group con reglas de acceso asociadas a cidr y SGs y una regla de salida estándar (any)

```
provider "aws" {
  region                  = "eu-west-1"
  shared_credentials_file = "~/.aws/credentials"
  profile                 = "cbgi-tf"
}

# Tageo de recursos utilizando locals
locals {
  # Common tags to be assigned to all resources
  common_tags = {
    Project             = "Desconocido"
    CostCenter          = "DESCONOCIDO"
    Application         = "TEST"
    Environment         = "DEV"
    Domain              = "COR"
  }
}

# Datos de la VPC de despliegue

data "aws_vpc" "vpc_dmz" {
  tags = {
    Name = "vpc-elz-dmz"   #cambiar por la vpc en la que quieres buscar
  }
}

module "sg-test" {
  source              = "git::https://gitlab-devops-spain.accenture.com/terraform/modules/aws/sg.git"
  sg_name             = "jm-test"
  sg_description      = "jm-test security group"
  vpc_id              = data.aws_vpc.vpc_dmz.id
  
  # TAGS
  common_tags         = local.common_tags

  # CIDR rules
  rule_cidr = {
    rule1 = {
      from_port       = "443"
      to_port         = "443"
      protocol        = "tcp"
      type            = "ingress"
      from_cidr       = ["10.0.0.128/25"]
      description     = "ingrees for DMZ network"
    }
    rule2 = {
      from_port       = "443"
      to_port         = "443"
      protocol        = "tcp"
      type            = "ingress"
      from_cidr       = [module.instance-test.ec2-ip]
      description     = "ingrees for instance-test IP"
    }
    rule3 = {# default egress rule
      from_port       = 0
      to_port         = 0
      protocol        = "-1"
      type            = "egress"
      from_cidr       = ["0.0.0.0/0"]
      description     = "egress default  rule"
    }
  }

  # SG rules
  rule_sg = {
    rule1 = {
      from_port   = 0
      to_port     = 0
      protocol    = "-1"
      type        = "ingress"
      from_group  = module.sg-test2.sg-id
      description = "egress for sg-test2 security group"
    }
  }
}
```

