# sg  module definition

resource "aws_security_group" "sg" {
  name              = upper(var.sg_name)
  description       = var.sg_description
  vpc_id            = var.vpc_id
  tags              = merge(var.common_tags, tomap({"Name" = lower(var.sg_name)}))
 
  lifecycle {
    create_before_destroy = true
  }
}

# defining rules
resource "aws_security_group_rule" "rule-sg" {
  for_each                 = var.rule_sg != null ? var.rule_sg : {}
  type                     = each.value.type
  from_port                = each.value.from_port
  to_port                  = each.value.to_port
  protocol                 = each.value.protocol
  source_security_group_id = each.value.from_group
  security_group_id        = aws_security_group.sg.id
  description              = each.value.description
}

resource "aws_security_group_rule" "rule-cidr" {
  for_each                 = var.rule_cidr != null ? var.rule_cidr : {}
  type                     = each.value.type
  from_port                = each.value.from_port
  to_port                  = each.value.to_port
  protocol                 = each.value.protocol
  cidr_blocks              = each.value.from_cidr
  security_group_id        = aws_security_group.sg.id
  description              = each.value.description
}
