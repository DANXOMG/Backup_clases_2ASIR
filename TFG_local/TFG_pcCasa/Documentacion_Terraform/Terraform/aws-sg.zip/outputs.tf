# module sg rules outputs

# ingress rule id
output "sg-id" {
    value = aws_security_group.sg.id
}

output "sg-arn" {
    value = aws_security_group.sg.arn
}

output "rule-sg" {
    value = [for rule in aws_security_group_rule.rule-sg : rule.id]
}

output "rule-cidr" {
    value = [for rule in aws_security_group_rule.rule-cidr : rule.id]
}
