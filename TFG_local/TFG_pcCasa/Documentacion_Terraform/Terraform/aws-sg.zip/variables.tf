# SG module variables
variable "sg_name" {
  default = null
}
variable "vpc_id" {
  default = null
}
variable "sg_description" {
  default = "Terraform SG"
}
variable "rule_sg" {
  type = map
  default = null
}
variable "rule_cidr" {
  type = map
  default = null
}
variable "common_tags" {
  type = map
  default = {}
}